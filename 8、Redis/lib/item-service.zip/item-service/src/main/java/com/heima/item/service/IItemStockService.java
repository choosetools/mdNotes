package com.heima.item.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.heima.item.pojo.ItemStock;

public interface IItemStockService extends IService<ItemStock> {
}
